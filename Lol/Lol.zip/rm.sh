rm *.class
rm *.tokens
rm LolPass1*.java
rm LolPass2*.java