public class BreakOutsideForeach extends Exception {
}