public class InitCallsSenderException extends Exception {
}