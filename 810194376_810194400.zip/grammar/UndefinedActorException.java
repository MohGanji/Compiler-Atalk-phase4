public class UndefinedActorException extends Exception {
}