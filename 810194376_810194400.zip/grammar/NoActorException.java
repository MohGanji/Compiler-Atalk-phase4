public class NoActorException extends Exception {
}