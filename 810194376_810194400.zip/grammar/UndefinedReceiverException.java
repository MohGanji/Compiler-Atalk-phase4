public class UndefinedReceiverException extends Exception {
}