rm *.class
rm *.tokens
rm Lol*.java