public class LValueException extends Exception {
}