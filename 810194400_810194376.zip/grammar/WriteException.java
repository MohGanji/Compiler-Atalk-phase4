public class WriteException extends Exception {
}