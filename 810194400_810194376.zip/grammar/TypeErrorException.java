public class TypeErrorException extends Exception {
}