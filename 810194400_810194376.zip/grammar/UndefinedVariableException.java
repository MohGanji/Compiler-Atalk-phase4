public class UndefinedVariableException extends Exception {
}