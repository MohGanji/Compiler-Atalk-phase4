public class SymbolTableGlobalVariableItem extends SymbolTableVariableItem {
	
	public SymbolTableGlobalVariableItem(Variable variable, int offset) {
		super(variable, offset);
	}

	@Override
	public Register getBaseRegister() {
		return Register.GP;
	}

	@Override
	public boolean useMustBeComesAfterDef() {
		return false;
	}
}