public class ForeachIterativeException extends Exception {
}